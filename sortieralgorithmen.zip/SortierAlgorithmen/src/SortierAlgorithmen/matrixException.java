package SortierAlgorithmen;

public class matrixException extends Exception {

	matrixException() {
		super("Die ArrayL�nge darf 500 nicht �berschreiten!");
	}
}
