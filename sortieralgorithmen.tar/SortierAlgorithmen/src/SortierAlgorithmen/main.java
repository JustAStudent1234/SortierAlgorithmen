package SortierAlgorithmen;

import java.awt.event.*;
import java.lang.reflect.Array;

import javax.swing.*;

public class main {

	public static void main(String[] args) {

		try {
			GUI c = new GUI(150);
		} catch (Exception e) {
			e.getStackTrace();
		}

	}

}
